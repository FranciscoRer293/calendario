# Guia Futebol (Protótipo Android TV)

📅 Mostra um jogo fixo do Brasileirão: Flamengo x Palmeiras (14/09 - 21h30)  
📺 Com botões para abrir Globoplay ou Premiere na sua Android TV.

## Como usar no GitHub Actions
1. Crie um repositório vazio no GitHub.
2. Faça upload de todos esses arquivos para o repositório.
3. Vá na aba **Actions** → selecione **Build Android APK** → **Run workflow**.
4. Espere ~3 minutos.  
5. O APK vai aparecer para download nos **Artifacts**.

Depois é só instalar o APK na sua Android TV (via pendrive ou ADB).
