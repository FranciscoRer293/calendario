rootProject.name = "GuiaFutebol"
include(":app")
